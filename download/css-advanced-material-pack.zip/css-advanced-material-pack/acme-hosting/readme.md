# Democontent von Bastian Allgeier
Dank an (Bastian)[https://bastianallgeier.com/] für den Content aus dem (Kirby)[https://getkirby.com] Workshop.